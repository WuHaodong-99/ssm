import org.junit.Test;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.internal.DefaultShellCallback;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 吴浩东
 * @create 2021-03-29 11:13
 */
public class MbgTest {
    @Test
    public void testMBG() throws Exception{
        List<String> warning = new ArrayList<String>();
        boolean overwrite = true;
        File configFile = new File("D:\\ssm\\src\\main\\resources\\mbg.xml");
        ConfigurationParser cp = new ConfigurationParser(warning);
        Configuration config = cp.parseConfiguration(configFile);
        DefaultShellCallback callback = new DefaultShellCallback(overwrite);
        MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config,callback,warning);
        myBatisGenerator.generate(null);
        System.out.println("文件生成完成");

    }
}

