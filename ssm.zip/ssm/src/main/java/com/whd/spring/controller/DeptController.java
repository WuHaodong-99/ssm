package com.whd.spring.controller;


import com.whd.spring.bean.Dept;
import com.whd.spring.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author 吴浩东
 * @create 2021-03-29 14:05
 */
@Controller
public class DeptController {
    @Autowired
    public DeptService deptService;
    @GetMapping("/dept/list")
    public String list(Model model){
        List<Dept> allDept = deptService.findAllDept();
        model.addAttribute("list",allDept);
        return "dept/list";
    }

    @GetMapping("/dept/insertUI")
    public String insertUI(){
        return "dept/insert";
    }

    @PostMapping("/dept/insert")
    public String insert(Dept dept){
        deptService.insert(dept);
        return "redirect:/dept/list";
    }

}
