package com.whd.spring.controller;

import org.springframework.stereotype.Controller;

/**
 * @author 吴浩东
 * @create 2021-03-29 11:46
 */
@Controller
public class LoginController {
}
