package com.whd.spring.service;

import com.whd.spring.bean.Dept;


import java.util.List;

/**
 * @author 吴浩东
 * @create 2021-03-29 14:28
 */
public interface DeptService {
    List<Dept> findAllDept();

    void insert(Dept dept);
}
