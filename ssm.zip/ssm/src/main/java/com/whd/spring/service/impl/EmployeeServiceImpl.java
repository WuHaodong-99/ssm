package com.whd.spring.service.impl;

import com.whd.spring.bean.Employee;
import com.whd.spring.mapper.EmployeeMapper;
import com.whd.spring.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author 吴浩东
 * @create 2021-03-29 11:19
 */
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    public EmployeeMapper employeeMapper;

    public List<Employee> findAllEmp() {
        return employeeMapper.selectByExample(null);
    }

}
