package com.whd.spring.service.impl;

import com.whd.spring.bean.Dept;
import com.whd.spring.mapper.DeptMapper;
import com.whd.spring.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author 吴浩东
 * @create 2021-03-29 14:28
 */
@Service
@Transactional
public class DeptServiceImpl implements DeptService {
    @Autowired
    public DeptMapper deptMapper;
    public List<Dept> findAllDept(){
        return deptMapper.selectByExample(null);
    }
    public void insert(Dept dept){
        deptMapper.insertSelective(dept);
    }


}
