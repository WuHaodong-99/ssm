package com.whd.spring.controller;

import com.whd.spring.bean.Employee;
import com.whd.spring.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * @author andy
 * @create 2021-03-25 14:26
 */
@Controller
@RequestMapping("/employee")
public class EmployeeController {
    @Autowired
    public EmployeeService employeeService;

    @GetMapping("/list")
    public String list(Model model){
        List<Employee> list = employeeService.findAllEmp();
        model.addAttribute("list",list);
        return "list";
    }
}
