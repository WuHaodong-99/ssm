package com.whd.spring.service;

import com.whd.spring.bean.Employee;

import java.util.List;

/**
 * @author 吴浩东
 * @create 2021-03-29 11:18
 */
public interface EmployeeService {
    List<Employee> findAllEmp();
}
